﻿using GraphQL;
using GraphQL.Types;
using GraphQL.Utilities;
using $safeprojectname$.GraphQLSchema.Types;
using $safeprojectname$.Infrastructure.Extensions;
using $ext_safeprojectname$.Common.Extensions;
using $ext_safeprojectname$.Interfaces;
using Microsoft.AspNetCore.Http;
using System;

namespace $safeprojectname$.GraphQLSchema.Queries.Groups
{

    public class TestGroupQueries : ScopedObjectGraphType
    {
        public TestGroupQueries(IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            Name = "testQueries";

            #region example
            /*
             query($input: Int!)
             {
                testQueries
                {
                    demoQuery(input: $input)
                    {
                        code
                    }
                }
             }


             {
                "input": 1
             }
            */
            #endregion
            FieldAsync<TestResponseType>(
                "demoQuery",
                    arguments: new QueryArguments(new QueryArgument<NonNullGraphType<IntGraphType>> { Name = "input" }),
                    resolve: async context =>
                    {
                        //example of scopes authorization, if it is configured from startup.cs
                        //_httpContextAccessor.HttpContext.ValidateScopes("read");

                        return await GetService<ITestService>().DemoQuery(context.GetArgument<int>("input"));
                    });


        }
    }
}
