﻿using GraphQL;
using GraphQL.Types;
using GraphQL.Utilities;
using $safeprojectname$.GraphQLSchema.Mutations;
using $safeprojectname$.GraphQLSchema.Queries;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace $safeprojectname$.GraphQLSchema
{

    public class GraphQLMainSchema : Schema
    {

        public GraphQLMainSchema(IDependencyResolver resolver) : base(resolver)
        {
            Query = resolver.Resolve<RootQuery>();
            Mutation = resolver.Resolve<RootMutation>();
        }

    }
}
