﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    //need to map Resouces.resx
    public class Resources
    {
    }
}
