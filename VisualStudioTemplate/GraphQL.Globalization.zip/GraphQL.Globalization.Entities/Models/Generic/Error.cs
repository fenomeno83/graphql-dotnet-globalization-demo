﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Models.Generic
{

    public class ErrorMessage
    {
        public string Field { get; set; }
        public string Message { get; set; }
    }
}
