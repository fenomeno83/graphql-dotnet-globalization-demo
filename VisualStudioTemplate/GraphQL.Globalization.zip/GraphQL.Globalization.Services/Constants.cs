﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public static class Messages
    {
        public const string EnumError = "Type T must inherit from System.Enum. Found: ";
    }
}
