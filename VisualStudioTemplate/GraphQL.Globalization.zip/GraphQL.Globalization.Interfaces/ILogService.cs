﻿using System;
using System.Collections.Generic;
using System.Text;
using static $ext_safeprojectname$.Entities.Models.Enums;

namespace $safeprojectname$
{
    
    public interface ILogService
    {
        void WriteLog(LogLevelL4N logLevel, string log);

    }
}
